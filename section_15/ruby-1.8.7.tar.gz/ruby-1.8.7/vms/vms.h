#ifndef VMSRUBY_VMS_H_INCLUDED
#define VMSRUBY_VMS_H_INCLUDED

extern int isinf(double);
extern int isnan(double);
extern int flock(int fd, int oper);

extern int vsnprintf();

#endif
