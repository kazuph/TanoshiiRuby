#ifndef VMSRUBY_H_INCLUDED
#define VMSRUBY_H_INCLUDED

void _vmsruby_init(void);
long _vmsruby_set_switch(char *, char *);

#endif /* VMSRUBY_H_INCLUDED */
